package com.eduit.convertidor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioButton cmRB;
    RadioButton pulgadasRB;
    EditText ingresarET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cmRB       = findViewById(R.id.cmRB);
        pulgadasRB = findViewById(R.id.pulgadasRB);
        ingresarET = findViewById(R.id.ingresarET);

    }


    public void Conversor(View view) {

        String medidaSTR = ingresarET.getText().toString() ;


        if (medidaSTR.isEmpty()){

            Toast.makeText(getApplicationContext(),
                    "Por favor ingresar un valor",
                    Toast.LENGTH_LONG).show();


        }else{
            Float medida = Float.parseFloat(medidaSTR);
            Double medidaFinal;
            if (cmRB.isChecked())
            {

                medidaFinal = convertirPulgadaACm(medida);
                cmRB.setChecked(false);
                pulgadasRB.setChecked(true);
                ingresarET.setText(String.valueOf(medidaFinal));

            }else
                {

                    medidaFinal = convertirCmAPulgada(medida);
                    cmRB.setChecked(true);
                    pulgadasRB.setChecked(false);
                    ingresarET.setText(String.valueOf(medidaFinal));

                }

        }

    }

    public double convertirPulgadaACm(Float medida){


        return medida * 0.39;
    };

    public double convertirCmAPulgada(Float medida){

        return medida * 2.54;
    };



}
