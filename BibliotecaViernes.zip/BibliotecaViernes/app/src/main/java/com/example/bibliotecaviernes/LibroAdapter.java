package com.example.bibliotecaviernes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class LibroAdapter extends ArrayAdapter {

    ArrayList<libros> libros;

    public LibroAdapter(@NonNull Context context, @NonNull ArrayList<libros> lista) {
        super(context, R.layout.fila_libro, lista);

        this.libros = lista;
    }
    //funcion getView


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        //si el covertView es null = no hay nada
        View fila = convertView;

        if(fila == null){

            //inflador
            fila = LayoutInflater.from(parent.getContext()).inflate(R.layout.fila_libro,parent,false);

        }
        //buscar libro que va en esa fila
        libros libroACargar = libros.get(position);

        //ver cuales son los textViews
        TextView tituloTV = fila.findViewById(R.id.tituloTV);
        TextView autorTV = fila.findViewById(R.id.autorTV);

        //cargar datos de libros en esos textviews
        tituloTV.setText(libroACargar.getTitulo());
        autorTV.setText(libroACargar.getAutor());


        return fila;
    }
}
