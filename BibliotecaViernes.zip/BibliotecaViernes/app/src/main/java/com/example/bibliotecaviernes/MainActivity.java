package com.example.bibliotecaviernes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //creo los libros
        libros HP = new libros(0,"Harry Potter","J.K. Rowling");
        libros Fundation = new libros(1,"Fundation","Isac Asimov");
        libros GO = new libros(1,"1984","George Orwell");

        //cargo los libros
        ArrayList<libros> libros = new ArrayList<>();
        libros.add(HP);
        libros.add(Fundation);
        libros.add(GO);

        //inicializo la lista de libros (ListView)
        ListView ListaLibrosLV =findViewById(R.id.ListaLibrosLV);
        LibroAdapter adaptadorAvanzado = new LibroAdapter(this,libros);

        ListaLibrosLV.setAdapter(adaptadorAvanzado);

    }
}