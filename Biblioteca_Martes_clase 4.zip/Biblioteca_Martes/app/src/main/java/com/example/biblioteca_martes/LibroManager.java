package com.example.biblioteca_martes;

import java.util.ArrayList;
import java.util.List;

public class LibroManager {

    private static LibroManager instancia;
    private List<Libro> libros;

    private LibroManager() {
        libros = new ArrayList<>();
    }

    public static LibroManager getInstance() {
        if (instancia == null) {
            instancia = new LibroManager();
        }

        return instancia;

    }

    public List<Libro> getLibros() {
        return libros;
    }

    public void setLibros(List<Libro> libros) {
        this.libros = libros;
    }

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }
}
