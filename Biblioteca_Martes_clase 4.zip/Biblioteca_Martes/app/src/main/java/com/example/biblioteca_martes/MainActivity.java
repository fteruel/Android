package com.example.biblioteca_martes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    LibroAdapter adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<Libro> libros = new ArrayList<>();
        libros.add(new Libro(0, "Fundation", "Isaac Asinov"));
        libros.add(new Libro(1, "Harry potter y el caliz de fuego", "J.K.Rowling"));
        libros.add(new Libro(2, "Canción de hielo y fuego", "George R. R. Martin"));
        libros.add(new Libro(3, "Los juegos del hambre en llamas", "Suzanne Collins"));
        libros.add(new Libro(4, "Maze runner", "James Dashner"));


        LibroManager.getInstance().setLibros(libros);


        //adaptador va a tener que ser Adaptador de Libros
        ListView listaLibrosLV = findViewById(R.id.listaLibrosLV);
        adaptador = new LibroAdapter(getApplicationContext(), LibroManager.getInstance().getLibros());
        listaLibrosLV.setAdapter(adaptador);


        listaLibrosLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                List<Libro> libros = LibroManager.getInstance().getLibros();

                Libro libroAMostrar = libros.get(position);

                String mensaje = "El libro Seleccionado es : " + libroAMostrar.getNombre() + " del Autor: " + libroAMostrar.getAutor();

                Toast.makeText(getApplicationContext(), mensaje, Toast.LENGTH_LONG ).show();

            }
        });

    }

    @Override
    protected void onResume() {
        super.onResume();
        adaptador.agregarLibros(LibroManager.getInstance().getLibros());
        adaptador.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.opciones, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if( item.getItemId() == R.id.itemAgregar){

            Intent llamarAgregarLibro = new Intent(MainActivity.this, AgregarLibroActivity.class);

            startActivity(llamarAgregarLibro);

        }

        return super.onOptionsItemSelected(item);
    }
}
