package com.example.biblioteca_martes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AgregarLibroActivity extends AppCompatActivity {

    private EditText tituloET;
    private EditText autorET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_libro);

        tituloET = findViewById(R.id.tituloET);
        autorET = findViewById(R.id.autorET);
    }

    public void ingresarLibro(View view) {

        String titulo = tituloET.getText().toString();
        String autor = autorET.getText().toString();

        if (titulo.isEmpty() || autor.isEmpty()){

            Toast.makeText(AgregarLibroActivity.this, R.string.completar, Toast.LENGTH_LONG).show();

        }else{

            Libro libroNuevo = new Libro();
            libroNuevo.setNombre(titulo);
            libroNuevo.setAutor(autor);

            LibroManager.getInstance().agregarLibro(libroNuevo);

            finish();
        }



    }
}
