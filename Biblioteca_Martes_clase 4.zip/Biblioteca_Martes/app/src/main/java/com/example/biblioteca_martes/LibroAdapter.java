package com.example.biblioteca_martes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class LibroAdapter extends ArrayAdapter {

    List<Libro> libros;
    TextView nombreTV;
    TextView autorTV;


    public LibroAdapter(Context context, List objects) {
        super(context, R.layout.fila_lista_libro, objects);
        libros = objects;
    }

    public void agregarLibros(List libros){
        this.libros = libros;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View fila = convertView;
        if(fila == null){
            fila = LayoutInflater
                    .from(parent.getContext())
                    .inflate(R.layout.fila_lista_libro, parent, false);
        }

        Libro libroActual = libros.get(position);
        nombreTV = fila.findViewById(R.id.nombreTV);
        autorTV= fila.findViewById(R.id.autorTV);

        nombreTV.setText(libroActual.getNombre());
        autorTV.setText(libroActual.getAutor());

        return fila;

    }
}
