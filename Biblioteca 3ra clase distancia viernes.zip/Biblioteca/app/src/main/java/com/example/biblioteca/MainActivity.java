package com.example.biblioteca;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creo una lista de Libros vacia
        List<Libro> libros = new ArrayList<>();

        //cargo libros a la lista
        libros.add(new Libro(0, "1984", "Gorge Orwell"));
        libros.add(new Libro(1, "Canción de hielo y fuego", "George R. R. Martin"));
        libros.add(new Libro(2, "Harry Potter y el cáliz de fuego", "J. K. Rowling"));
        libros.add(new Libro(3, "Los juegos del hambre en llamas", "Suzanne Collins"));
        libros.add(new Libro(4, "Maze runner", "James Dashner"));

        //traigo a java el listView
        ListView bibliotecaLV = findViewById(R.id.bibliotecaLV);

        //creo el adaptador y lo seteo
        LibroAdapter adaptador = new LibroAdapter(libros);

        bibliotecaLV.setAdapter(adaptador);



    }

}
