package com.example.biblioteca_martes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<Libro> libros = new ArrayList<>();
        libros.add(new Libro(0, "Fundation", "Isaac Asinov"));
        libros.add(new Libro(1, "Harry potter y el caliz de fuego", "J.K.Rowling"));
        libros.add(new Libro(2, "Canción de hielo y fuego", "George R. R. Martin"));
        libros.add(new Libro(3, "Los juegos del hambre en llamas", "Suzanne Collins"));
        libros.add(new Libro(4, "Maze runner", "James Dashner"));





        //adaptador va a tener que ser Adaptador de Libros
        ListView listaLibrosLV = findViewById(R.id.listaLibrosLV);
        ListAdapter adaptador = new LibroAdapter(getApplicationContext(), libros);
        listaLibrosLV.setAdapter(adaptador);




    }
}
