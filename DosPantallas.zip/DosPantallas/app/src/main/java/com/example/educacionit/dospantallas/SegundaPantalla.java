package com.example.educacionit.dospantallas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SegundaPantalla extends AppCompatActivity {

    String nombrePrimeraPantalla;
    String nombreDeUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_pantalla);

        Intent llamadaDePrimeraPantalla = getIntent();
        nombrePrimeraPantalla = llamadaDePrimeraPantalla.getExtras().getString("nombreActivity");

        TextView activityTV = (TextView) findViewById(R.id.activityTV);
        activityTV.setText(nombrePrimeraPantalla);

    }

    public void enviarUsuario(View view) {

        EditText usuarioET = (EditText)findViewById(R.id.usuarioET);

        nombreDeUsuario = usuarioET.getText().toString();

        Intent llamarPrimeraPantalla = new Intent();

        llamarPrimeraPantalla.putExtra("nombreUsuario", nombreDeUsuario);

        setResult(RESULT_OK,llamarPrimeraPantalla);

        finish();

    }
}
