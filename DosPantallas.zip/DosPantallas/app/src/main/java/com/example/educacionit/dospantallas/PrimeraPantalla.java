package com.example.educacionit.dospantallas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class PrimeraPantalla extends AppCompatActivity {

    String nombreDeUsuario;
    final int resultado = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_primera_pantalla);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        TextView usuarioTV = (TextView)findViewById(R.id.usuarioTV);

        super.onActivityResult(requestCode, resultCode, data);

        nombreDeUsuario = data.getStringExtra("nombreUsuario");

        usuarioTV.setText(nombreDeUsuario);

    }

    public void IngresarUsuario(View view) {

        Intent llamarSegundaPantalla= new Intent(this, SegundaPantalla.class);


        llamarSegundaPantalla.putExtra("nombreActivity","PrimeraPantalla");

        startActivityForResult(llamarSegundaPantalla, resultado);

    }
}
