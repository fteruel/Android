package com.example.educacionit.dospantallas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class PrimerPantalla extends AppCompatActivity {

    TextView nombreUsuarioTV = (TextView)findViewById(R.id.nombreUsuarioTV);
    final int resultado = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_primer_pantalla);
    }

    public void ingresarNombreUsuario(View view) {

        Intent quieroNombreUsuario = new Intent(this,SegundaPantalla.class);

        quieroNombreUsuario.putExtra("nombreActivity", "PrimerPantalla");

        startActivityForResult(quieroNombreUsuario, resultado);

    }
}
