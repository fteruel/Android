package com.eduit.biblioteca;

import android.content.Context;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibroManager {

    private static LibroManager instance;
    private List<Libro> libros;
    private Dao<Libro, Integer> dao;

    public void setLibros(List<Libro> libros) {

        try {
            dao.create(libros);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        this.libros = libros;
    }

    private LibroManager(Context context){
        OrmLiteSqliteOpenHelper helper =
                OpenHelperManager.getHelper(context, DBhelper.class);

        try {
            dao = helper.getDao(Libro.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        libros = new ArrayList<>();
    }

    public List<Libro> getLibros() {

        try {
            return dao.queryForAll();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        ;
        return libros;
    }

    public void agregarLibro(Libro libro){

        try {
            dao.create(libro);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        libros.add(libro);
    }

    public static LibroManager getInstance(Context context){
        if (instance == null){

            instance = new LibroManager(context);
        }
        return instance;

    }
}
