package com.eduit.biblioteca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class agregar_libro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_libro);

        SharedPreferences pref = getSharedPreferences(MainActivity.WIFI, MODE_PRIVATE);

        Boolean estado_wifi;

        estado_wifi = pref.getBoolean(MainActivity.ESTADO_WIFI, true);

        if (estado_wifi) {

            Toast.makeText(getApplicationContext(),
                    "WIFI ONLY ON", Toast.LENGTH_LONG).show();

        }


    }

    public void agregarLibro(View view) {

        EditText tituloET = findViewById(R.id.tituloET);
        EditText autorET  = findViewById(R.id.autorET);

        String titulo, autor;

        titulo = tituloET.getText().toString();
        autor  = autorET.getText().toString();

        if (titulo.isEmpty() || autor.isEmpty()){

            Toast.makeText(getApplicationContext(),
                    "Por favor Completar campos",
                    Toast.LENGTH_LONG).show();


        }else {

            int id = LibroManager.getInstance(getApplicationContext()).getLibros().size() + 1;

            Libro libroAAgregar = new Libro(id, titulo, autor);

            LibroManager.getInstance(getApplicationContext()).agregarLibro(libroAAgregar);

            finish();

        }



    }
}
