package com.eduit.biblioteca;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {



    final static public String WIFI = "WIFI_ONLY";
    final static public String ESTADO_WIFI = "estado_Wifi";




    private ArrayList<Libro> Libros;
    private AdaptadorLibro adaptador;
    private Toolbar toolTB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolTB = findViewById(R.id.toolTB);

        setSupportActionBar(toolTB);
        getSupportActionBar().setTitle("Biblioteca");

          Libros = new ArrayList<>();

        Libros.add( new Libro(1, "1984", "George Orwell "));
        Libros.add( new Libro(2, "Harry Potter", "J.K.Rowling"));
        Libros.add( new Libro(3, "Game of thrones", "Gorge R.R. Martin"));
        Libros.add( new Libro(4, "Fundation", "Isaac Asimov"));

        ListView LibrosLV = (ListView) findViewById(R.id.ListaBiblioteca);

        LibroManager.getInstance(getApplicationContext()).setLibros(Libros);

        adaptador = new AdaptadorLibro(Libros);
        LibrosLV.setAdapter(adaptador);

        //SharedPref

        Boolean WIFI_ONLY = true;

        SharedPreferences pref = getSharedPreferences(WIFI, MODE_PRIVATE);

        SharedPreferences.Editor editor = pref.edit();

        editor.putBoolean(ESTADO_WIFI, WIFI_ONLY);

        editor.apply();




    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_agregar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {


        if (item.getItemId() == R.id.item_agregar){


            Intent agregar_libro = new Intent(MainActivity.this,
                    com.eduit.biblioteca.agregar_libro.class);

            startActivity(agregar_libro);

        }



        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onResume() {

        adaptador.setLibros(LibroManager.getInstance(getApplicationContext()).getLibros());
        adaptador.notifyDataSetChanged();

        super.onResume();


    }
}
