package com.example.educacionit.farcel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText tempET;
    private RadioButton celciusRB;
    private RadioButton fahRB;
    private Button convertirBT;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tempET      = (EditText) findViewById(R.id.tempET);
        celciusRB   = (RadioButton)findViewById(R.id.celciusRB);
        fahRB       = (RadioButton) findViewById(R.id.fahRB);
        convertirBT = (Button) findViewById(R.id.convertirBT);

        convertirBT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String temp;
                Float tempFloat;
                temp = tempET.getText().toString();

                if (temp.length() == 0){

                    final Toast alert = Toast.makeText(getApplicationContext(),"Campo Temp Vacio", Toast.LENGTH_LONG);
                    alert.show();

                    return;
                }

                tempFloat = Float.parseFloat(temp);

                if(celciusRB.isChecked()){

                    tempFloat = deFahACel(tempFloat);
                    tempET.setText(String.valueOf(tempFloat));

                    celciusRB.setChecked(false);
                    fahRB.setChecked(true);

                }else
                {
                    tempFloat = deCelAFah(tempFloat);
                    tempET.setText(String.valueOf(tempFloat));

                    celciusRB.setChecked(true);
                    fahRB.setChecked(false);
                }



            }
        });

    }

    private Float deCelAFah(Float tempFloat) {

        return ((tempFloat * 9) / 5) + 32;
    }

    private Float deFahACel(Float tempFloat) {

        return ((tempFloat - 32) * 5 / 9);
    }
}
