package com.example.a3pantallas;

import java.util.ArrayList;
import java.util.List;

public class LibroManager {

    private static LibroManager instance;
    private List<Libro> libros;

    public void setLibros(List<Libro> libros) {
        this.libros = libros;
    }

    public static LibroManager getInstance() {
        if(instance == null){

            instance = new LibroManager();
        }
        return instance;
    }

    private LibroManager(){
        libros = new ArrayList<>();
    }


    public List<Libro> getLibros() {
        return libros;
    }

    public void agregarLibros(Libro libro){

        libros.add(libro);

    }
}
