package com.example.a3pantallas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;
import java.util.zip.Inflater;

public class adaptadorLibro extends BaseAdapter {

    private List<Libro> Libros;



    public void setLibros(List<Libro> libros) {
        this.Libros = libros;
    }

    public adaptadorLibro(List<Libro> libros){this.Libros = libros; }

    @Override
    public int getCount() {
        return Libros.size();
    }

    @Override
    public Object getItem(int position) {
        return Libros.get(position);
    }

    @Override
    public long getItemId(int position) {
        return Libros.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View Fila;
        //tomo el layout creado para un fila y hago que se adapte al tamaño que se espera en la pantalla
        Fila = LayoutInflater.
                from(parent.getContext())
                .inflate(R.layout.item_libro,parent ,false);

        Libro libro = Libros.get(position);

        TextView txtNombre = (TextView) Fila.findViewById(R.id.txtNombre);
        TextView txtAutor  = (TextView) Fila.findViewById(R.id.txtAutor);

        txtNombre.setText(libro.getNombre());
        txtAutor.setText(libro.getAutor());



        return Fila;
    }
}
