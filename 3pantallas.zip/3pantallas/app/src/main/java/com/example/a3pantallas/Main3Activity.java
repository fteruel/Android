package com.example.a3pantallas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Main3Activity extends AppCompatActivity {

    private Toolbar toolbar;
    private List<Libro> libros; //Creo una lista de libros
    private List<Libro> getLibros(){
        //una funcion que me devueleve la lista de libros que este guardada en la instancia actual.
        return LibroManager.getInstance().getLibros();
    }
    private adaptadorLibro adaptador;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        //traigo la toolbar y agrego un titulo
        toolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Mis libros");

        //creo una lista de libros y agrego libros iniciales a la lista

        libros = new ArrayList<>();

        libros.add(new Libro(1, "Harry Potter y el caliz de fuego", "J.K.Rowling"));
        libros.add(new Libro(2, "Harry Potter y la camara secreta", "J.K.Rowling"));
        libros.add(new Libro(3, "Harry Potter y la orden del fenix", "J.K.Rowling"));
        libros.add(new Libro(4, "Harry Potter y las reliquias de la muerte", "J.K.Rowling"));
        libros.add(new Libro(5, "Una cancion de fuego y hielo", "George R. R. Matin"));

        //agrego los libros a la instancia que vamos a usar
        LibroManager.getInstance().setLibros(libros);
        //creo un nuevo adaptador
        adaptador = new adaptadorLibro(libros);

        ListView LibrosLV = (ListView) findViewById(R.id.LibrosLV);
        LibrosLV.setAdapter(adaptador);
        //escucho la lista de libros y veo que libro fue el seleccionado y hago un Toast para mostrarlo
        LibrosLV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String libroSeleccionado =
                        libros.get(position).getNombre();

                Toast.makeText(getApplicationContext(),
                        "El libro seleccionado es: " + libroSeleccionado ,
                        Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    protected void onResume() {

        //cada vez que hay se vuelve a esta actividad desde otra se vuelve a revisar la lista de libros y se notifican los cambios al adaptador
        adaptador.setLibros(getLibros());
        adaptador.notifyDataSetChanged();

        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() ==  R.id.agregarItem){


            Intent agregar = new Intent(Main3Activity.this, agregarActivity.class);

            startActivity(agregar);

        }

        return super.onOptionsItemSelected(item);
    }
}


