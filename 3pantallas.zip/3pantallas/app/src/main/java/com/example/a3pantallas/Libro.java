package com.example.a3pantallas;

//defino un Libro

public class Libro {
    private int id;
    private String nombre;
    private String autor;

    public Libro(int id, String nombre, String autor) {
        this.id = id;
        this.nombre = nombre;
        this.autor = autor;
    }


    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getAutor() {
        return autor;
    }
}
