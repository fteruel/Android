package com.example.a3pantallas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import java.util.List;

public class agregarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
    }

    EditText tituloET;
    EditText autorET;

    public void agregarLibro(View view) {

        tituloET = (EditText) findViewById(R.id.tituloET);
        autorET= (EditText) findViewById(R.id.autorET);

        String titulo = tituloET.getText().toString();
        String autor = autorET.getText().toString();

        if(!titulo.isEmpty() && !autor.isEmpty()){

            Libro libro= new Libro(0, titulo, autor);
            LibroManager.getInstance().agregarLibros(libro);
            finish();
        }


    }
}



