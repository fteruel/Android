package com.example.loginsql;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Logueado extends AppCompatActivity {

    Dao<Usuario, Integer> dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logueado);

        //genero el helper para tener una clase para llamar
        OrmLiteSqliteOpenHelper helper = OpenHelperManager.getHelper(getApplicationContext(), DBHelper.class);

        //genero el dao

        try {
            dao = helper.getDao(Usuario.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //genero una lista de usuarios con toda la tabla
        List<Usuario> usuarios = new ArrayList<>();

        try {

            usuarios = dao.queryForAll();

        } catch (SQLException e) {
            e.printStackTrace();
        }


        //cargo datos a view
        Usuario usuarioLogueado = usuarios.get(0);

        TextView usuarioBDTV = findViewById(R.id.usuarioBDTV);
        TextView passwordBDTV = findViewById(R.id.passwordBDTV);
        TextView mensajeBDTV = findViewById(R.id.mensajeBDTV);


        usuarioBDTV.setText(usuarioLogueado.getNombre());
        passwordBDTV.setText(usuarioLogueado.getPassword());
        mensajeBDTV.setText(usuarioLogueado.getMensaje());


    }
}
