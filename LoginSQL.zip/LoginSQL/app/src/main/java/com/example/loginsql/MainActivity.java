package com.example.loginsql;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.j256.ormlite.android.apptools.OpenHelperManager;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;

public class MainActivity extends AppCompatActivity {


    EditText usuarioET;
    EditText passwordET;
    private SharedPreferences prefs;
    public static String USUARIO = "usuario";
    public static String PASSWORD = "password";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void Ingresar(View view) {
        prefs = getPreferences(MODE_PRIVATE);

        usuarioET  =  findViewById(R.id.usuarioET);
        passwordET =  findViewById(R.id.passwordET);


        String usuario  = usuarioET.getText().toString();
        String password = passwordET.getText().toString();


        if(!(usuario.isEmpty() || password.isEmpty())){

            String usuarioGuardado = prefs.getString(USUARIO, "");
            String passguardado = prefs.getString(PASSWORD, "");

            Log.d("ingreso", usuarioGuardado);
            Log.d("ingreso", passguardado);

            if(password.equals(passguardado)&& usuario.equals(usuarioGuardado)){


                Intent intent = new Intent(MainActivity.this, Logueado.class);
                startActivity(intent);

                //meto al usuario en la base de datos

                String MensajeBienvenida = "Bienvenido a la app: " + usuario;
                Usuario user = new  Usuario(0, usuario, password, MensajeBienvenida);

                Dao<Usuario, Integer> dao;
                OrmLiteSqliteOpenHelper helper = OpenHelperManager.getHelper(getApplicationContext(), DBHelper.class);

                try {

                    dao = helper.getDao(Usuario.class);
                    dao.create(user);


                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }
        }
    }

    public void Registrar(View view) {
        prefs = getPreferences(MODE_PRIVATE);

        usuarioET  =  findViewById(R.id.usuarioET);
        passwordET =  findViewById(R.id.passwordET);

        String usuario  = usuarioET.getText().toString();
        String password = passwordET.getText().toString();

        if(!(usuario.isEmpty() || password.isEmpty())){

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(USUARIO, usuario);
            editor.putString(PASSWORD, password);

            editor.commit();

            Log.d("registro", usuario);
            Log.d("registro", password);


        }


    }
}
