package com.example.loginsql;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "usuarios")
public class Usuario {

    @DatabaseField(id=true)
    private int id;

    @DatabaseField
    private String nombre;

    @DatabaseField
    private String password;

    @DatabaseField
    private String mensaje;

    public Usuario(int id, String nombre, String password, String mensaje){
        this.id = id;
        this.nombre = nombre;
        this.password = password;
        this.mensaje = mensaje;
    }

    public Usuario(){
            }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
}
