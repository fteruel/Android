package com.example.biblioteca_sabado;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

public class LibroAdaptador extends ArrayAdapter {

    ArrayList<Libro> libros;


    public LibroAdaptador(@NonNull Context context, @NonNull ArrayList<Libro> libros) {

        super(context, R.layout.fila_libro, libros);

        this.libros = libros;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View Fila = convertView;

        if(Fila == null){

            Fila = LayoutInflater
                    .from(parent.getContext())
                    .inflate(R.layout.fila_libro, parent, false);
        }

        Libro libroACargar = libros.get(position);

        TextView nombreTV = Fila.findViewById(R.id.nombreTV);
        TextView autorTV = Fila.findViewById(R.id.autorTV);

        nombreTV.setText(libroACargar.getNombre());
        autorTV.setText(libroACargar.getAutor());

        return Fila;
    }
}
