package com.example.biblioteca_sabado;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Libro> libros = new ArrayList<>();

        libros.add(new Libro("0", "1984", "George Orwell"));
        libros.add(new Libro("1","Fundation", "Isaac Asimov "));
        libros.add(new Libro("2", "Harry Potter", "J.k.Rowling"));
        libros.add(new Libro("3", "El niño de pijama de raya", "john Boyne"));


        ListView listaLibrosLV = findViewById(R.id.listaLibrosLV);

        LibroAdaptador adaptador = new LibroAdaptador(MainActivity.this, libros);

        listaLibrosLV.setAdapter(adaptador);



    }

    // 1984 George Orwell
    // Fundation Isaac Asimov
    // Harry Potter J.k.Rowling
    // El niño de pijama de rayas jahn Boyne
    // El alquimista  Paulo Coelho
    // El principe maquiavelo



}
