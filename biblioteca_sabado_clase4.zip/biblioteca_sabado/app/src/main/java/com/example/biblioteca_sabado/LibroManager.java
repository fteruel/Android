package com.example.biblioteca_sabado;

import java.util.ArrayList;
import java.util.List;

public class LibroManager {

    private ArrayList<Libro> libros;
    private static LibroManager instance;


    private LibroManager() {
    }

    public static LibroManager getInstance() {
        if (instance == null){

            instance = new LibroManager();

        }

        return instance;
    }


    public void setLibros(ArrayList<Libro> libros) {
        this.libros = libros;
    }

    public ArrayList<Libro> getLibros() {
        return libros;
    }

    public void agregarLibro(Libro libroNuevo){
        this.libros.add(libroNuevo);
    }
}
