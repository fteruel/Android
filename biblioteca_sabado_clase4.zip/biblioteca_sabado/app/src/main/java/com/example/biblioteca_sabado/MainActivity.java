package com.example.biblioteca_sabado;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    LibroAdaptador adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Libro> libros = new ArrayList<>();

        libros.add(new Libro(0, "1984", "George Orwell"));
        libros.add(new Libro(1,"Fundation", "Isaac Asimov "));
        libros.add(new Libro(2, "Harry Potter", "J.k.Rowling"));
        libros.add(new Libro(3, "El niño de pijama de raya", "john Boyne"));

        LibroManager.getInstance().setLibros(libros);

        // El alquimista  Paulo Coelho
        // El principe maquiavelo


        ListView listaLibrosLV = findViewById(R.id.listaLibrosLV);

        adaptador = new LibroAdaptador(MainActivity.this, LibroManager.getInstance().getLibros());

        listaLibrosLV.setAdapter(adaptador);
    }

    @Override
    protected void onResume() {


        adaptador.agregarLibros(LibroManager.getInstance().getLibros());
        adaptador.notifyDataSetChanged();

        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_libros, menu);

        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId() == R.id.menu_item_agregar){

            Intent llamarAgregarActivity = new Intent(MainActivity.this, AgregarLibroActivity.class);

            startActivity(llamarAgregarActivity);

        }

        return super.onOptionsItemSelected(item);
    }


}
