package com.example.biblioteca_sabado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AgregarLibroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_libro);
    }

    public void agregarLibro(View view) {

        EditText nombreET = findViewById(R.id.nombreET);
        EditText autorET = findViewById(R.id.autorET);

        String nombreSTR = nombreET.getText().toString();
        String autorSTR = autorET.getText().toString();

        if(nombreSTR.isEmpty() || autorSTR.isEmpty()){

            Toast.makeText(getApplicationContext(),"Por favor ingresar nombre y titulo", Toast.LENGTH_LONG).show();

            return;

        }

        Libro libroNuevo = new Libro(10, nombreSTR, autorSTR);

        LibroManager.getInstance().agregarLibro(libroNuevo);

        finish();

    }
}
