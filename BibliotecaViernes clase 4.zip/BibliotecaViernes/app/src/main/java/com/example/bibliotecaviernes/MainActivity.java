package com.example.bibliotecaviernes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    LibroAdapter adaptadorAvanzado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //creo los libros
        Libro HP = new Libro(0,"Harry Potter","J.K. Rowling");
        Libro Fundation = new Libro(1,"Fundation","Isac Asimov");
        Libro GO = new Libro(1,"1984","George Orwell");

        //cargo los libros
    //        ArrayList<Libro> libros = new ArrayList<>();
//        libros.add(HP);
//        libros.add(Fundation);
//        libros.add(GO);



        LibroManager manager = LibroManager.getInstance();
        manager.agregarLibro(HP);
        manager.agregarLibro(Fundation);
        manager.agregarLibro(GO);


        //inicializo la lista de libros (ListView)
        ListView ListaLibrosLV =findViewById(R.id.ListaLibrosLV);
        adaptadorAvanzado = new LibroAdapter(this, manager.getLibros());

        ListaLibrosLV.setAdapter(adaptadorAvanzado);

    }

    @Override
    protected void onResume() {

        adaptadorAvanzado.setLibros(LibroManager.getInstance().getLibros());

        adaptadorAvanzado.notifyDataSetChanged();

        super.onResume();
    }


    //cargar el menu de opciones


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_libros,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == R.id.menu_item_agregar){

            Intent llamarAgregarActivity = new Intent(MainActivity.this, AgregarLibroActivity.class);

            startActivity(llamarAgregarActivity);


        }


        return super.onOptionsItemSelected(item);
    }
}