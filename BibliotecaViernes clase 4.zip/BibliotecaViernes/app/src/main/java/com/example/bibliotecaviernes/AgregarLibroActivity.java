package com.example.bibliotecaviernes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AgregarLibroActivity extends AppCompatActivity {

    EditText tituloET;
    EditText autorET;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_libro);

        tituloET = findViewById(R.id.tituloET);
        autorET  = findViewById(R.id.autorET);

    }

    public void agregarLibro(View view) {

        String titulo = tituloET.getText().toString();
        String autor  = autorET .getText().toString();

        //ver si los alguno de los campos estan vacios
        //si ninguno esta vacio
        if (!(titulo.isEmpty()) && !(autor.isEmpty())){

            //crear un libro aux y le cargo el titulo y autor

            Libro libroNuevo = new Libro();

            libroNuevo.setTitulo(titulo);
            libroNuevo.setAutor(autor);

            // agregar el libro a el Manager

            LibroManager.getInstance().agregarLibro(libroNuevo);

            finish();

        }else {

            Toast.makeText(this, "Por Favor ingresar un libro valido", Toast.LENGTH_LONG).show();

        }



    }
}