package com.example.bibliotecaviernes;

import java.util.ArrayList;

public class LibroManager {

    private ArrayList<Libro> libros;
    private static LibroManager instance;

    private LibroManager(){

        libros = new ArrayList<>();
    }

    public static LibroManager getInstance(){
        //pregunto si la instancia existe
        if(instance == null){
            //como no existe la creo
            instance = new LibroManager();

        }
        return  instance;
    }

    public ArrayList<Libro> getLibros(){
        return libros;
    }

    public void agregarLibro(Libro libroAAgregar){
        libros.add(libroAAgregar);
    }

}
