package com.example.educacionit.listaception;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * Created by educacionit on 26/06/2017.
 */
class miAdptador extends ArrayAdapter<String>{

    public miAdptador(Context contexto, String[] shows){

        super(contexto,R.layout.fila_layout, shows);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        LayoutInflater inflador = LayoutInflater.from(getContext());

        View filaV = inflador.inflate(R.layout.fila_layout, parent, false);

        String show = getItem(position);

        TextView showTV = (TextView) filaV.findViewById(R.id.showTV);

        showTV.setText(show);

        return filaV;
    }
}
