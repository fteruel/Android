package com.example.biblioteca;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Agregar extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar);
    }

    public void agregarLibro(View view) {

        EditText tituloET = findViewById(R.id.tituloET);
        EditText autorET  = findViewById(R.id.autorET);

        String tituloSTR = tituloET.getText().toString();
        String autorSRT  = autorET.getText().toString();

        Libro libroNuevo = new Libro(7, tituloSTR, autorSRT);


        LibroManager.getInstance().agregarLibro(libroNuevo);

        finish();


    }
}
