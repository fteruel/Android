package com.example.biblioteca;

import java.util.ArrayList;
import java.util.List;

public class LibroManager {

    private static LibroManager instance;
    private List<Libro> biblioteca;


    public static LibroManager getInstance(){
        if(instance == null){
            instance = new LibroManager();
        }
        return instance;
    }


    private LibroManager(){
        biblioteca = new ArrayList<>();
    }

    public List<Libro> getBiblioteca() {
        return biblioteca;
    }

    public void agregarLibro(Libro libro){
        biblioteca.add(libro);
    }
}
