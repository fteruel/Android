package com.example.biblioteca;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class LibroAdapter extends BaseAdapter {

    private List<Libro> libros;

    public LibroAdapter(List<Libro> libros) {
        this.libros = libros;
    }
    //cantidad de libros
    @Override
    public int getCount() {
        return libros.size();
    }

    //libro en posicion position
    @Override
    public Object getItem(int position) {
        return libros.get(position);
    }

    //id del elemento en esa posicion
    @Override
    public long getItemId(int position) {
        return libros.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        //la llamada estaba bien, cerre y volvi a abrir el Android Studio y se arreglo solo.

        View fila = LayoutInflater
               .from(parent.getContext())
               .inflate(R.layout.fila_libro, parent, false);

        Libro libro = libros.get(position);

        TextView nombreTV = fila.findViewById(R.id.nombreTV);
        TextView autorTV = fila.findViewById(R.id.autorTV);

        nombreTV.setText(libro.getNombre());
        autorTV.setText(libro.getAutor());


        return fila;
    }
}
