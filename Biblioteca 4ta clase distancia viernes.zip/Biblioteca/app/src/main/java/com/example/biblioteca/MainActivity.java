package com.example.biblioteca;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    LibroAdapter adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //cargo tool bar y seteo titulo
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Biblioteca");



        //cargo libros a la lista
        LibroManager.getInstance().agregarLibro(new Libro(0, "1984", "Gorge Orwell"));
        LibroManager.getInstance().agregarLibro(new Libro(1, "Canción de hielo y fuego", "George R. R. Martin"));
        LibroManager.getInstance().agregarLibro(new Libro(2, "Harry Potter y el cáliz de fuego", "J. K. Rowling"));
        LibroManager.getInstance().agregarLibro(new Libro(3, "Los juegos del hambre en llamas", "Suzanne Collins"));
        LibroManager.getInstance().agregarLibro(new Libro(4, "Maze runner", "James Dashner"));

        //traigo a java el listView
        ListView bibliotecaLV = findViewById(R.id.bibliotecaLV);

        //creo el adaptador y lo seteo
        adaptador = new LibroAdapter(LibroManager.getInstance().getBiblioteca());

        bibliotecaLV.setAdapter(adaptador);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_add, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

       if(item.getItemId() == R.id.item_agregar){

           Intent intent = new Intent(MainActivity.this, Agregar.class);
           startActivity(intent);

       }



        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onResume() {

        adaptador.notifyDataSetChanged();

        super.onResume();
    }
}
